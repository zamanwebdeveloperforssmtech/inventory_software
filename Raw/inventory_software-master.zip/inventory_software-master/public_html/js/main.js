$(document).ready(function(){
	// alert("Hello Friends");
})
